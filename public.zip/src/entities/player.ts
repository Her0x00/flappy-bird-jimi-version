import { GameObjects, Scene } from "phaser";

export default class Player extends GameObjects.Rectangle {

    constructor(scene: Scene) {
        super(
            scene,
            100,
            300,
            40,
            40,
            0x0066ff
        )

        scene.add.existing(this)

        scene.physics.add.existing(this)

        this.body.setallowGravity(false)
    }
}