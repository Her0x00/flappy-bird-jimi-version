import { Scene } from "phaser";
import Player from "../entities/player";

export default class GameScene extends Scene {

    public player?: Player
    
    constructor() {
        super({key: 'game-scene'})
    }

    preload(){

    }

    create(){
        this.player = new Player(this)
    }
    
    update(time: number, delta: number): void {
        
    }
}

